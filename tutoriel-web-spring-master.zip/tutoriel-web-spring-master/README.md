Réalisation d'application Web simple avec Spring
===================

Ce dépôt contient les sources de l'article : [Tutoriel sur la réalisation d'application Web simple avec Spring](http://rpouiller.developpez.com/tutoriels/spring/application-web-spring-hibernate/)
